print"install script hello world" 
